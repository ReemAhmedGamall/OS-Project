#include "kernel/types.h"
#include "user/user.h"

int main(void) {
  printf("Running psinfo syscall...\n");
  psinfo();  // Call our new syscall
  exit(0);
}

