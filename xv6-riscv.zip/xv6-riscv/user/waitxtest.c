#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(void) {
  uint64 status;
  uint64 cpu_time;
  uint64 mem_max;

  int pid = fork();
  if (pid == 0) {
    // Child process: do some work
    for (volatile int i = 0; i < 1000000; i++);
    exit(42);
  } else {
    // Parent process: waitx
    waitx(&status, &cpu_time, &mem_max);
    printf("Child exited with status %d\n", (int)status);
    printf("CPU time used: %d ticks\n", (int)cpu_time);
    printf("Max memory used: %d bytes\n", (int)mem_max);
  }
  exit(0);
}
